$(function(){
	$('.datepicker').datepicker().on('changeDate', function(ev){
		$(this).datepicker('hide');
	});			
});
$(document).ready(function(){
	$("#banner").click(function(){
		window.location = "index.html";				
	});
	$("#log_button").click(function(){
		window.location = "login.html"
	});
	$("#reg_button").click(function(){
		window.location = "reg.html";
	});
	$("#page_button").click(function(){
		window.location = "my_page.html";
	});
	$("#home_button").click(function(){
		window.location = "homework.html";
	});
	$("#baby_button").click(function(){
		window.location = "babysitter.html";
	});
	$("#info_button").click(function(){
		window.location = "info.html";
	});
	$("#cont_button").click(function(){
		window.location = "contact.html";
	});
	$("#logout_button").click(function(){
		console.log("Bla");
	});
	$("#forgot_pass_button").click(function(){
		console.log("test")
	});
	$("#change").click(function(){
		window.location = "change.html";
	});
	$("#drop_down").change(function() {	
		var value = $(this).val();
		if(value == 1){ window.location = "index.html";   }
		if(value == 2){ window.location = "reg.html"; 	  }
		if(value == 3){ window.location = "my_page.html"; }
		if(value == 4){ window.location = "homework.html";}
		if(value == 5){ window.location = "babysitter.html";}
		if(value == 6){ window.location = "info.html";	  }
		if(value == 7){ window.location = "contact.html"; }  
	});
	$("#hideTemplate").show();
	$("#hideChild").show();
});