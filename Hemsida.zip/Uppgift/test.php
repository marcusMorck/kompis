<?php
require "includes/config.php";
$startTime = $_GET['starttime'];
$endTime = $_GET['endtime'];

$sql = "SELECT * FROM `bookingtutor` WHERE `startTime` >= '" . $startTime . "' AND `endTime` <= '" . $endTime . "'";
$stm = $pdo->prepare($sql);
$stm->execute([]);

foreach($stm as $row) {
	echo $row['userName'] . "\n";
}
?>