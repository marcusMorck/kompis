<?php
session_start();
if (isset($_SESSION['session_id'])){

?>

<!DOCTYPE html> 
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="description" content="Bokning">
		<title>Boka Läxhjälp</title>
		<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	</head>
	<body>
		<div style="display:none" id="hideChild">
			<div id="template">
			</div>
			<div id="container">
				<form action="../includes/booktutor.php" method="post">
					<input id="namn_bokning" type="text" name="name" placeholder="Namn" required="required"/>
					<input id="ämne" type="text" name="subject" placeholder="Ämne" required="required">
					<select id="vakt" name=""> 
						<option value="1">Välj Läxhjälp</option>
					</select> 
					<p id="bokaLäx">Boka Läxhjälp<p/>
					<p id="starttid">Starttid:</p>
					<p id="sluttid">Sluttid:</p>
					<input id="start" type="datetime-local" name="starttime" onchange="received();" required="required">
					<input id="end" type="datetime-local" name="endtime" onchange="received();" required="required">
					<button id="boka_hjälp" type="submit" name="book" class="btn">Boka</button>
				</form>
			</div>
			<script>
				$(function(){
					$('#template').load('template.html');
				});
				function received(){
					$('#vakt').empty();
					$('#vakt').append($('<option>', {
						value: 1,
						text: 'Välj Läxhjälp'
					}));
					var start = document.getElementById("start").value;
					start = start.replace("T", " ");
					var end = document.getElementById("end").value;
					end = end.replace("T", " ");
					
					if(window.XMLHttpRequest){
						xmlhttp = new XMLHttpRequest();//modern
					}else{
						xmlhttp = new ActiveXObjext("Microsoft.XMLHTTP");//gamla webbläsare
					}
					xmlhttp.onreadystatechange = function(){
						if(this.readyState == 4 && this.status == 200){
							var select = document.getElementById("vakt");
							var result = this.responseText.split("\n");
							for(var i = 0; i < result.length; i++){
								if(result[i] != "") {
									var option = document.createElement("option");
									option.text = result[i];
									select.add(option);
								}
							}
						}
					};
					xmlhttp.open("GET", "/../test.php?starttime=" + start + "&endtime=" + end, true);
					xmlhttp.send();
					//php behöver hitta läxhjälp mellan start&end
					//skriva ut namnen(echo)
				}
			</script>
		</div>
	</body>
</html>
<?php
}
else{
    echo "Du måste logga in för att få behörighet till denna sidan!";
    header("Refresh:5 ../html/login.html");
}
?>