<?php
session_start();
if (isset($_SESSION['session_id'])){

?>

<!DOCTYPE html> 
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="description" content="Bokning">
		<title>Boka Barnvakt</title>
		<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	</head>
	<body>
		<div style="display:none" id="hideChild">
			<div id="template">
			</div>
			<div id="container">
				<form action="../includes/bookbabysitter.php" method="post">
					<input id="namn_bokning" type="text" name="name" placeholder="Namn" required="required"/>
					<select id="barn" name="children" placeholder="namn" required="required"> 
						<option value="1">Antal Barn</option>
						<option value="2">1</option> 
						<option value="3">2</option>
						<option value="4">3</option>
						<option value="4">>4</option>
					</select>
					<select id="vakt" name=""> 
						<option value="1">Välj Barnvakt</option>
					</select> 
					<p id="bokaBarn">Boka Barnvakt<p/>
					<p id="starttid">Starttid:</p>
					<p id="sluttid">Sluttid:</p>
					<input id="start" type="datetime-local" name="starttime" required="required">
					<input id="end" type="datetime-local" name="endtime" required="required">
					<button id="boka_hjälp" type="submit" name="book" class="btn">Boka</button>
				</form>
			</div>
			<script>
				$(function(){
					$('#template').load('template.html');
				});
				function received(){
					$('#vakt').empty();
					$('#vakt').append($('<option>', {
						value: 1,
						text: 'Välj Läxhjälp'
					}));
					var start = document.getElementById("start").value;
					start = start.replace("T", " ");
					var end = document.getElementById("end").value;
					end = end.replace("T", " ");
					
					if(window.XMLHttpRequest){
						xmlhttp = new XMLHttpRequest();//modern
					}else{
						xmlhttp = new ActiveXObjext("Microsoft.XMLHTTP");//gamla webbläsare
					}
					xmlhttp.onreadystatechange = function(){
						if(this.readyState == 4 && this.status == 200){
							var select = document.getElementById("vakt");
							var result = this.responseText.split("\n");
							for(var i = 0; i < result.length; i++){
								if(result[i] != "") {
									var option = document.createElement("option");
									option.text = result[i];
									select.add(option);
								}
							}
						}
					};
					xmlhttp.open("GET", "/../test2.php?starttime=" + start + "&endtime=" + end, true);
					xmlhttp.send();
					//php behöver hitta läxhjälp mellan start&end
					//skriva ut namnen(echo)
				}
			</script>
		</div>
	</body>
</html>
<?php
}
else{
    echo "Du måste logga in för att få behörighet till denna sidan!";
    header("Refresh:5 ../html/login.html");
}
?>