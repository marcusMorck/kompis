﻿$(document).ready(function(){
	$.ajax({
		url:"../includes/session.php",
		cache:false,
		success:function(data){
			if(data == "true"){
				$("#logout_button").show();
				$("#log_button").hide();
			}else{
				$("#logout_button").hide();
			}
		}
	});
	$("#banner").click(function(){
		window.location = "index.html";				
	});
	$("#log_button").click(function(){
		window.location = "login.html"
	});
	$("#reg_button").click(function(){
		window.location = "reg.html";
	});
	$("#page_button").click(function(){
		window.location = "my_page.php";
	});
	$("#home_button").click(function(){
		window.location = "homework.php";
	});
	$("#baby_button").click(function(){
		window.location = "babysitter.php";
	});
	$("#info_button").click(function(){
		window.location = "info.html";
	});
	$("#cont_button").click(function(){
		window.location = "contact.html";
	});
	$("#logout_button").click(function(){
		window.location = "../includes/logout.inc.php"
	});
	$("#forgot_pass_button").click(function(){
		console.log("Glömt Lösenord")
	});
	$("#change").click(function(){
		window.location = "change.html";
	});
	$("#drop_down").change(function() {	
		var value = $(this).val();
		if(value == 1){ window.location = "index.html";   }
		if(value == 2){ window.location = "reg.html"; 	  }
		if(value == 3){ window.location = "my_page.php"; }
		if(value == 4){ window.location = "homework.php";}
		if(value == 5){ window.location = "babysitter.php";}
		if(value == 6){ window.location = "info.html";	  }
		if(value == 7){ window.location = "contact.html"; }  
	});
	$("#hideTemplate").show();
	$("#hideChild").show();
});