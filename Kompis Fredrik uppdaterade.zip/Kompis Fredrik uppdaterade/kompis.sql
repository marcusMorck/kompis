-- phpMyAdmin SQL Dump
-- version 4.4.15.5
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Feb 14, 2017 at 08:18 PM
-- Server version: 5.5.49-log
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kompis`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookingbabysitter`
--

CREATE TABLE IF NOT EXISTS `bookingbabysitter` (
  `id` int(11) NOT NULL,
  `userName` varchar(45) COLLATE utf8_swedish_ci NOT NULL,
  `userId` int(11) NOT NULL,
  `children` int(1) NOT NULL,
  `babysitter` varchar(45) COLLATE utf8_swedish_ci NOT NULL,
  `startTime` datetime NOT NULL,
  `endTime` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data for table `bookingbabysitter`
--

INSERT INTO `bookingbabysitter` (`id`, `userName`, `userId`, `children`, `babysitter`, `startTime`, `endTime`) VALUES
(1, 'Fredrik Hietala', 1, 1, 'Anna Andersson', '2017-02-15 12:00:00', '2017-02-15 19:00:00'),
(4, 'Kalle Karlsson', 8, 2, 'Sara Svensson', '2017-02-17 18:00:00', '2017-02-17 22:00:00'),
(11, 'Kalle Karlsson', 8, 2, 'Eva Karlsson', '2017-02-21 17:00:00', '2017-02-21 21:00:00'),
(12, 'Sven Svensson', 9, 2, 'Eva Karlsson', '2017-02-17 16:00:00', '2017-02-17 21:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `bookingtutor`
--

CREATE TABLE IF NOT EXISTS `bookingtutor` (
  `id` int(11) NOT NULL,
  `userName` varchar(45) COLLATE utf8_swedish_ci NOT NULL,
  `userId` int(11) NOT NULL,
  `subject` varchar(20) COLLATE utf8_swedish_ci NOT NULL,
  `tutor` varchar(45) COLLATE utf8_swedish_ci NOT NULL,
  `startTime` datetime NOT NULL,
  `endTime` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data for table `bookingtutor`
--

INSERT INTO `bookingtutor` (`id`, `userName`, `userId`, `subject`, `tutor`, `startTime`, `endTime`) VALUES
(2, 'Fredrik Hietala', 1, 'Backend', 'Johan Johansson', '2017-02-17 10:00:00', '2017-02-17 14:00:00'),
(3, 'Kalle Karlsson', 8, 'Matematik', 'Anders Andersson', '2017-02-18 12:00:00', '2017-02-18 15:00:00'),
(11, 'Sven Svensson', 9, 'Engelska', 'Johan Johansson', '2017-02-21 16:00:00', '2017-02-21 18:00:00'),
(12, 'Annika Karlsson', 10, 'Historia', 'Fredrik Karlsson', '2017-02-22 15:00:00', '2017-02-22 18:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(11) NOT NULL,
  `name` varchar(45) COLLATE utf8_swedish_ci NOT NULL,
  `reference` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `user` varchar(45) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `name`, `reference`, `user`) VALUES
(1, 'Anna Andersson', 'Duktig barnvakt', 'Barbro'),
(2, 'Johan Johansson', 'Lärt mina barn att förstå matte', 'Magnus'),
(3, 'Eva Karlsson', 'Jättebra med barn', 'Charlotte'),
(4, 'Fredrik Hietala', 'Duktig på problemlösning', 'Marcus'),
(5, 'Anna Andersson', 'Kommer alltid i tid', 'Sven');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `name` varchar(45) COLLATE utf8_swedish_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `role` varchar(20) COLLATE utf8_swedish_ci DEFAULT NULL,
  `hashedPw` varchar(250) COLLATE utf8_swedish_ci NOT NULL,
  `adress` varchar(30) COLLATE utf8_swedish_ci NOT NULL,
  `zipCode` int(5) NOT NULL,
  `city` varchar(30) COLLATE utf8_swedish_ci NOT NULL,
  `phoneNumber` varchar(15) COLLATE utf8_swedish_ci NOT NULL,
  `reference` varchar(4000) COLLATE utf8_swedish_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `role`, `hashedPw`, `adress`, `zipCode`, `city`, `phoneNumber`, `reference`) VALUES
(1, 'Fredrik Hietala', 'hietala.fredrik@gmail.com', NULL, '$2y$10$wM8rpnOE7loE3ULsk02vI.BY7ineWnEvfGMZNk1cq7C60rdcqAtzm', 'Trekungagatan 1', 44237, 'Kungälv', '0700111222', NULL),
(2, 'Anna Andersson', 'anna@gmail.com', 'Barnvakt', '$2y$10$l78H5wo2SipKdct0Z4KwjuBUdW8whHigP/y0aEp.nfNaTqPCDXUQm', 'Brynjegatan 1', 44237, 'Kungälv', '0700222333', NULL),
(3, 'Fredrik Karlsson', 'fredrikkarlsson45@gmail.com', 'Läxhjälp', '$2y$10$FQ72YBfsLI7NFVSYMfS7HeLPXw8ODiTSffrdaj1p1VXDx1dSzSw1K', 'Trekungagatan 13', 44237, 'Kungälv', '0707378219', NULL),
(4, 'Eva Karlsson', 'eva.karlsson@gmail.com', 'Barnvakt', '$2y$10$mIilpcrGg2yEHI1d45uBieN/S5Hpyk0PMJK/1k2TK08yUz6IOjAW.', 'Brynjegatan 3', 44237, 'Kungälv', '0733223456', NULL),
(5, 'Johan Johansson', 'Johansson@gmail.com', 'Läxhjälp', '$2y$10$N8tGnYlHEApt/60OX3aqH.Z9oACUdp8gf0dPEQUhlroG5ibNZvv6e', 'Klockarvägen 4', 44277, 'Romelanda', '0737556677', NULL),
(6, 'Sara Svensson', 'Sara.svensson@gmail.com', 'Barnvakt', '$2y$10$QS6sk0NaRtoRuS.Co/Zb4OxtUqXmusaiHVNTO0RjRCxZuR3qqtxIO', 'Kruthusgatan 17', 41104, 'Göteborg', '0733223456', NULL),
(7, 'Anders Andersson', 'Andy@gmail.com', 'Läxhjälp', '$2y$10$GS2AuYs85TX7.haRLbuJ5ufjHG/pZDyz43u2uEY.WTdCxtsO8mp4O', 'Egnahemsgatan 1', 44230, 'Kungälv', '707378222', NULL),
(8, 'Kalle Karlsson', 'kalle@gmail.com', NULL, '$2y$10$NFF8cz6QAd0J6LX6uzvEaev0ZtD1xhqHjOSgxzaQKfhaPN7XA4pBu', 'Trekungagatan 13', 44237, 'Kungälv', '0707121232', NULL),
(9, 'Sven Svensson', 'svennebanan@gmail.com', NULL, '$2y$10$aqHwQnpk7Z/JBo6RoAHZQ.Q5P5bkaS4CZnhn6.aYiLcIcKRuTGhoa', 'Kruthusgatan 17', 41104, 'Göteborg', '0733273958', NULL),
(10, 'Annika Karlsson', 'ankikarlsson@gmail.com', NULL, '$2y$10$MooRqHK4k5EQD/HF3VqzRe85Lz66DNQVuQ.LW/VsPuKwzpI0fZuWe', 'Nedre Fogelbergsgatan 5', 41128, 'Göteborg', '0737554433', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookingbabysitter`
--
ALTER TABLE `bookingbabysitter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookingtutor`
--
ALTER TABLE `bookingtutor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookingbabysitter`
--
ALTER TABLE `bookingbabysitter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `bookingtutor`
--
ALTER TABLE `bookingtutor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
